package com;

public abstract class Human extends LivingThing {

	public void read() {
		System.out.println("Human Read");
	}
	
	
	public abstract void abc();
	
}

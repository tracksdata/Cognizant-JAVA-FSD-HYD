package com;

public class Male extends Human {

	public void walk() {
		System.out.println("Male Walk");
	}

	@Override
	public void abc() {
		
	}

}

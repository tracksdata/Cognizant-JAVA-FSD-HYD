package com;

public abstract class LivingThing {

	// Common State

	// Common Behav
	public void eat() {
		System.out.println("LT Eat");
	}

	public void sleep() {
		System.out.println("LT sleep");
	}

	public abstract void walk();

}

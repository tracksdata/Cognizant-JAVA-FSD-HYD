package com;

public class Female extends Human {

	public void walk() {
		System.out.println("Female Walk");
	}

	@Override   // Annotation : JDK 1.5
	public void abc() {

	}

}

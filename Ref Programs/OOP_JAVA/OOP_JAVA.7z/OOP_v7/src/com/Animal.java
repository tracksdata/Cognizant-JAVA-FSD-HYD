package com;

public class Animal extends LivingThing {

	public void walk() {
		System.out.println("Animal Walk");
	}
}

package com;

public class ImpNote {

	// Dont put operational code inside class directly.

}

package com;

class Pqr {

	// state

	public void method1(int arg) {
		System.out.println("Method 1");
	}

	public int method2() {
		return 12;
	}

	public int method3() {

		int val = 0;

		if (val > 0) {
			return 1;
		} else {
			return 0;
		}

	}

	public int method4() {
		return 12;
		// System.out.println("After return"); // Un-reachable
	}

	public String method5() {

		return "Hello";
	}

	public Pqr() {

	}

	public void Pqr() {

		// A, L , R

		// If, else

		// for , while , do-while

		// switch-case

		// ternary op

	}

}

public class MethodDemo {

	public static void main(String[] args) {

	}

}

package com;

public class Publisher {

	int pubCode;

}

package com;

public class Book {

	int bookISBN;

	// Pointer/reference/address to publisher Obj
	Publisher pubRef =new Publisher();
	// No Obj reference
	Publisher pubRef2 = null;

	
	
}

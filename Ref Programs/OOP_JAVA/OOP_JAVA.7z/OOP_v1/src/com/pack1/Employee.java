package com.pack1;

public class Employee {

	// State

	// Behav

	public void listen() {

	}

	public static void training() {

	}

}

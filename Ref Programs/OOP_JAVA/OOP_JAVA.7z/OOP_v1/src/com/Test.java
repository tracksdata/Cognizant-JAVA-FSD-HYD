package com;

import com.cust.Customer;
import com.pack1.Employee;

/*
 *  JRE
 *  -----
 *  
 *   have main() , so  that JRE can invoke, to Run Application.
 * 
 */

public class Test {

	public static void main(String[] args) {

		System.out.println("START");

		Customer cust1 = new Customer();
		cust1.purchase();

		// -----------------------------
		Employee.training();

		Employee e = new Employee();
		e.listen();
		// e.training(); not Rec

		System.out.println("END");

	}

}

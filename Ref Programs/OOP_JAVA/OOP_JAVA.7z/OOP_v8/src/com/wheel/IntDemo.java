package com.wheel;

interface A {

}

interface B {

}

interface C extends A, B {

}



public class IntDemo implements A,B {

}

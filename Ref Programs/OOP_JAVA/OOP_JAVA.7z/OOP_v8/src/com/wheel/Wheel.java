package com.wheel;

public interface Wheel {

	int RADIOUS = 5;

	void rotate();

}

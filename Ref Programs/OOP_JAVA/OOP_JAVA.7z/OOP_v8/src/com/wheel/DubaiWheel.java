package com.wheel;

public class DubaiWheel implements Wheel{

	public void rotate() {
		System.out.println("Dubai Wheel rotating");
	}

}

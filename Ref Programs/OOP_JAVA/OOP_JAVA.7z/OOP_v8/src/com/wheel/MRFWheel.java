package com.wheel;

public class MRFWheel implements Wheel {

	public void rotate() {
		System.out.println("MRF Wheel rotating");
	}

	public void iternalbehav() {
		System.out.println("MRF Internal Behav");
	}

}

package com.emp;

public class Manager extends Employee {

	// public String id;
	// public String name;
	
	public Manager() {
		super();
	}

}

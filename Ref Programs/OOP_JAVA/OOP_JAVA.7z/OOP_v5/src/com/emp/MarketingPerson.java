package com.emp;

public class MarketingPerson extends Employee{

}

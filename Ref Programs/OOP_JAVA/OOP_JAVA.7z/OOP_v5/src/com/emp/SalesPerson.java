package com.emp;

public class SalesPerson extends Employee {

	// state

	// public String id;
	// public String name;
	public double commision;

	public SalesPerson(String id, String name) {
		super(id, name);
		// super();
		// this.id = id;
		// this.name = name;
	}

	// behav
	public void abc() {
		// super();
	}

}

package com;

public class EmployeeAddress {
	
	String street;
	String country;

}

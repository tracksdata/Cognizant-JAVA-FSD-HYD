package com;

public class Employee {

	// State
	String empName;
	
	// Address
	EmployeeAddress empAddress;

	// Behav

}

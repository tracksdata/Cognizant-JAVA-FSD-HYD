package com;

public class LocalInnerClass {

	static class No_Static {

	}

	public static void main(String[] args) {

		class Local {

			//

		}

		Local local = new Local();

	}

}

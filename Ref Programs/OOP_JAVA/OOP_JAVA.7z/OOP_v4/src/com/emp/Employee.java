package com.emp;

public class Employee {

	public int empID;
	public String empName;
	public String empAddress;

	public Employee(int empID) {
		// this.empID = empID;
		this(empID, "NoName", "No Addr");
	}

	public Employee(String empName) {
		// this.empName = empName;
		this(0, empName, "No Addr");
	}

	public Employee(int empID, String empName) {
		// this.empID = empID;
		// this.empName = empName;
		this(empID, empName, "No Addr");
	}

	public Employee(int id, String empName, String empAddress) {
		empID = id;
		this.empName = empName;
		this.empAddress = empAddress;
	}

}

package p1;

public class C {

	public void c_ObjMethod() {

		A aobj = new A();

		// System.out.println(aobj.pri);

		System.out.println(aobj.de);
		System.out.println(aobj.pro);
		System.out.println(aobj.pub);

		System.out.println(A.pub_sta);

	}

}

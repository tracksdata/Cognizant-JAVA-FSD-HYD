package p1;

public class B extends A {

	public void b_ObjMethod() {

		// System.out.println(pri);
		System.out.println(de);
		System.out.println(pro);
		System.out.println(pub);

		System.out.println(pub_sta);

	}

}

package p2;

import p1.A;

public class E {

	public void e_ObjMethod() {

		A aobj = new A();

		// System.out.println(aobj.pri);
		// System.out.println(aobj.de);
		// System.out.println(aobj.pro);

		System.out.println(aobj.pub);

		System.out.println(A.pub_sta);

	}

}

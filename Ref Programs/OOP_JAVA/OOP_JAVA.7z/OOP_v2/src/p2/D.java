package p2;

import p1.A;

public class D extends A {

	public void d_ObjMethod() {

		// System.out.println(pri);
		// System.out.println(de);
		System.out.println(pro);
		System.out.println(pub);

		System.out.println(pub_sta);

	}

}

package p2;

public class C {

}

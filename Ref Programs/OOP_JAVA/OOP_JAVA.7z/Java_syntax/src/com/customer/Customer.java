package com.customer;

public class Customer {

	// 1. state var

	// a. object / Instance var
	int custID; // primitive
	String custName; // Reference

	// b. static / class var
	static float purDiscount; // Primitive.
	final static String SHOP_NAME = "HOMECARE";

	// 2. constructor
	public Customer() {
	}

	// 3. behav - Methods

	// a. Object/Instance Method

	void purchase() {
		// A, L , L
		// Conditional / looping
		// sending Message : Invoking Other Obj behav
		// Got result.
	}

	double getBudget() {

		return 100.00;
	}

	// b. static / class Methods

	static int getTodayDiscount() {
		// Get Discount for today
		return 100;
	}
	

	// 4. Inner classes

}

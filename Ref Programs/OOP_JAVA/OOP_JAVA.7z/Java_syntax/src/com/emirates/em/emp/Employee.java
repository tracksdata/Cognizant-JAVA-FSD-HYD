package com.emirates.em.emp;

public class Employee {

}

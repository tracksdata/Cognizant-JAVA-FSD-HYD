package com;

public class Robo extends LivingThing {

	public void eat() {
		System.out.println("Robo Elec Power");
	}

	@Override
	public void walk() {
		System.out.println("Robo Walk");
	}

}

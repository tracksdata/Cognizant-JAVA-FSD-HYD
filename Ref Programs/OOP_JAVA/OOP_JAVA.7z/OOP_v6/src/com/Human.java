package com;

public class Human extends LivingThing {

	public void read() {
		System.out.println("Human Read");
	}

	public void walk() {
		System.out.println("Human walk with 2 Legs");
	}

}

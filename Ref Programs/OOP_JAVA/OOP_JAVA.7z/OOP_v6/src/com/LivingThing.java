package com;

public class LivingThing {

	// State

	// behavior
	public void sleep() {
		System.out.println("LT Sleep");
	}

	public void eat() {
		System.out.println("LT Eat");
	}

	public void walk() {
		System.out.println("LT Walk");
	}

}
